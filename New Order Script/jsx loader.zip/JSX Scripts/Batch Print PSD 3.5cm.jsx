#target photoshop

function main(){
	app.doAction("Print all Stickers 3.5", "Batch Print Mac\'s 2.0" );
	app.doAction("Canon 3.5 v1", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v2", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v3", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v4", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v5", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v6", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v7", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v8", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v9", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v10", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v11", "Print Stickers Mac\'s 2.0" );
	app.doAction("Canon 3.5 v12", "Print Stickers Mac\'s 2.0" );    
}
main();