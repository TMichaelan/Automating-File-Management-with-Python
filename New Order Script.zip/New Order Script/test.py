import os

# os.system("cd / && D: && cd " + path_to_scripts + "\\" + jsx_script)
# os.system(path_to_scripts + "\\" + jsx_script)
# print( )